import React, { useEffect } from "react";
import jsPDF from "jspdf";

const PredictionReport = (props) => {
	useEffect(() => {
		var doc = new jsPDF("landscape", "px", "a4", "false");
		doc.text(60, 60, `Store Number : ${props.storeNum}`);
		doc.text(60, 80, `Predicted Sales : ${props.predictedResult}`);
		doc.save(`Store_${props.storeNum}.pdf`);
	}, []);
	return <></>;
};

export default PredictionReport;
