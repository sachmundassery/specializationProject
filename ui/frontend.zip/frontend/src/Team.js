import { TeamMembers } from "./data";
import Card from "react-bootstrap/Card";
import Image from "react-bootstrap/Image";

const Team = () => {
	return (
		<>
			<h3 style={{ textAlign: "center" }}>Team</h3>
			<main id="team">
				{TeamMembers.map((team) => {
					const { id, name, image } = team;

					return (
						<Card key={id} className="team-card">
							<Image src={image} roundedCircle className="team-img" />
							<Card.Body>
								<Card.Title className="text-center">{name}</Card.Title>
							</Card.Body>
						</Card>
					);
				})}
			</main>
		</>
	);
};

export default Team;
