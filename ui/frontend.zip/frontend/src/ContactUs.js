import React, { useState } from "react";

const ContactUs = () => {
	const [contactUs, setContactUs] = useState({
		name: "",
		email: "",
		message: "",
	});

	const handleChange = (e) => {
		const input = e.target.name;
		const value = e.target.value;
		console.log(input, value);
		setContactUs({ ...contactUs, [input]: value });
	};

	const handleSubmit = async (e) => {
		e.preventDefault();
		const formData = new FormData();

		formData.append("email", contactUs.email);
		formData.append("name", contactUs.name);
		formData.append("message", contactUs.message);
		const response = await fetch("http://127.0.0.1:8000/contactus", {
			method: "POST",
			body: formData,
		});
		const result = await response.json();

		if (result["response"] == true) {
			console.log("response successfully reached");
			alert("Message Received, Thankyou !!");
		}
	};

	return (
		<div id="contact">
			<main>
				<section className="container">
					<h3>Contact Us</h3>
					<label htmlFor="name">Name</label>
					<input
						type="text"
						name="name"
						id="name"
						value={contactUs.name}
						onChange={handleChange}
					/>

					<br />

					<label htmlFor="email">Email</label>
					<input
						type="email"
						name="email"
						id="email"
						value={contactUs.email}
						onChange={handleChange}
					/>

					<br />

					<label htmlFor="message">Message</label>
					<input
						type="text"
						name="message"
						id="message"
						value={contactUs.message}
						onChange={handleChange}
					/>

					<br />

					<button className="btn" type="button" onClick={handleSubmit}>
						Post
					</button>

					<br />
				</section>
			</main>
		</div>
	);
};

export default ContactUs;
